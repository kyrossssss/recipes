from flask import Flask, request, jsonify
from flask_cors import CORS  # Импортируем CORS
import smtplib
from email.mime.text import MIMEText

app = Flask(__name__)
CORS(app)  # Включаем CORS для всего приложения

# Настройки для отправки почты
EMAIL_ADDRESS = 'your_email@example.com'  # Ваша почта
EMAIL_PASSWORD = 'your_email_password'     # Ваш пароль от почты
SUPPORT_EMAIL = 'support@example.com'       # Почта, на которую будут приходить сообщения

@app.route('/support', methods=['POST'])
def support():
    data = request.json
    email = data.get('email')
    question = data.get('question')

    # Отправка письма
    try:
        msg = MIMEText(f"Вопрос от: {email}\n\n{question}")
        msg['Subject'] = 'Новый вопрос в техподдержку'
        msg['From'] = EMAIL_ADDRESS
        msg['To'] = SUPPORT_EMAIL

        with smtplib.SMTP('smtp.example.com', 587) as server:  # Замените на SMTP-сервер вашего провайдера
            server.starttls()
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.send_message(msg)

        return jsonify({"message": "Ваш вопрос успешно отправлен!"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
